create function timestamptz(date, time without time zone) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function timestamptz(date, time) owner to postgres;

